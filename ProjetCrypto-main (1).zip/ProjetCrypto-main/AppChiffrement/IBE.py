from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, GT, pair
from charm.toolbox.symcrypto import AuthenticatedCryptoAbstraction, MessageAuthenticator
import hashlib

class Boneh_Boyen_IBE:
    def __init__(self, groupObj):
        global group
        group = groupObj

    def setup(self):
        alpha = group.random(ZR)
        g = group.random(G1)
        g1 = g ** alpha
        g2 = group.random(G2)
        g2_alpha = g2 ** alpha
        k = group.random(ZR)
        n = 3
        s = 2
        U = [[group.random(G2) for _ in range(s)] for _ in range(n)]
        e = pair(g1, g2)
        params = {'g': g, 'g1': g1, 'g2': g2, 'U': U, 'k': k, 'e': e, 'n': n, 's': s}
        master_key = {'g2_alpha': g2_alpha}
        return params, master_key

    def KeyGen(self, params, ID, master_key):
        n = params['n']
        r = [group.random(ZR) for _ in range(n)]
        hashID = master_key['g2_alpha']
        for i in range(n):
            hashID *= (params['U'][i][int(ID[i]) % params['s']] ** r[i])
        g_r = [params['g'] ** r[i] for i in range(n)]
        return {'d0': hashID, 'dn': g_r}

    def encrypt(self, params, ID, message):
        # Convert message to bytes
        message_bytes = message.encode('utf-8')
        # Generate a random key for symmetric encryption
        sym_key = group.random(GT)
        sym_key_bytes = hashlib.sha256(sym_key.__str__().encode()).digest()  # Convert to bytes
        
        # Encrypt the message using symmetric encryption
        cipher = AuthenticatedCryptoAbstraction(sym_key_bytes)
        ciphertext = cipher.encrypt(message_bytes)
        
        # Encrypt the symmetric key using IBE
        n = params['n']
        e = params['e']
        g = params['g']
        U = params['U']
        t = group.random(ZR)
        A = (e ** t) * sym_key
        B = g ** t
        C = {i: (U[i][int(ID[i]) % params['s']] ** t) for i in range(n)}
        return {'A': A, 'B': B, 'C': C, 'ciphertext': ciphertext}

    def decrypt(self, params, dID, cipher_text):
        # Decrypt the symmetric key using IBE
        result = 1
        n = params['n']
        A = cipher_text['A']
        B = cipher_text['B']
        C = cipher_text['C']
        for i in range(n):
            result *= pair(C[i], dID['dn'][i])
        sym_key = A * (result / pair(B, dID['d0']))
        sym_key_bytes = hashlib.sha256(sym_key.__str__().encode()).digest()  # Convert to bytes
        
        # Decrypt the message using the symmetric key
        cipher = AuthenticatedCryptoAbstraction(sym_key_bytes)
        message_bytes = cipher.decrypt(cipher_text['ciphertext'])
        message = message_bytes.decode('utf-8')
        return message


# Initialisation du groupe de couplage et du schéma IBE
group = PairingGroup('SS512')
ibe = Boneh_Boyen_IBE(group)

# Configuration IBE
params, master_key = ibe.setup()

# Génération des clés utilisateurs pour IBE
keys_ibe = {}


'''
# Initialisation des utilisateurs et des rôles
users = {
    'alice': {'role': 'patient', 'profile': 'Profile de Alice'},
    'bob': {'role': 'patient', 'profile': 'Profile de Bob'},
    'eve': {'role': 'doctor', 'profile': 'Profile de Eve'},
    'steve': {'role': 'doctor', 'profile': 'Profile de Steve'}
}

# Affiche chaque utilisateur et son rôle
print("Liste des utilisateurs et leurs rôles :")
for user, data in users.items():
    print(f"{user}: {data['role']}")
'''
'''
for user in users:
    user_id = [ord(c) for c in user]  # Convertir l'ID utilisateur en liste d'entiers
    keys_ibe[user] = ibe.KeyGen(params, user_id, master_key)

# Chiffrement des profils utilisateurs avec IBE
encrypted_profiles = {}
for user, data in users.items():
    profile_msg = data['profile']
    encrypted_profiles[user] = ibe.encrypt(params, [ord(c) for c in user], profile_msg)
    users[user]['encrypted_profile'] = encrypted_profiles[user]

# Fonction d'accès aux profils
def access_profile(requester, user):
    if requester == user:
        decrypted_msg = ibe.decrypt(params, keys_ibe[requester], encrypted_profiles[user])
        return decrypted_msg
    else:
        return "Access Denied"

# Exemple d'accès aux profils
print(access_profile('alice', 'alice'))  # Doit afficher le profil de Alice
print(access_profile('bob', 'bob'))      # Doit afficher le profil de Bob
print(access_profile('eve', 'alice'))    # Doit afficher "Access Denied"
print(access_profile('steve', 'bob'))    # Doit afficher "Access Denied"
'''

