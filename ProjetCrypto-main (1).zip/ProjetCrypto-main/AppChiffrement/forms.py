from django import forms
from django.contrib.auth.forms import AuthenticationForm
from .models import Usera, Doctor, Appointment

from django import forms
from django.contrib.auth.forms import AuthenticationForm

from django.contrib.auth.forms import AuthenticationForm

from django import forms
from django.contrib.auth.forms import AuthenticationForm


from django.contrib.auth.forms import AuthenticationForm
from django import forms



class LoginForm(AuthenticationForm):
    username = forms.CharField(
        label="Email",
        widget=forms.EmailInput(attrs={"class": "form-control", "placeholder": "Entrez votre email"})
    )
    password = forms.CharField(
        label="Mot de passe",
        widget=forms.PasswordInput(attrs={"class": "form-control", "placeholder": "Entrez votre mot de passe"})
    )



from django import forms
from .models import Usera, Profile, Patient
from charm.toolbox.pairinggroup import PairingGroup
from .IBE import Boneh_Boyen_IBE
import hashlib
import json
import base64

# Initialisation du chiffrement IBE
group = PairingGroup('SS512')
ibe = Boneh_Boyen_IBE(group)
params, master_key = ibe.setup()

def serialize_ciphertext(cipher):
    """Convertit un objet chiffré en JSON Base64."""
    return base64.b64encode(json.dumps({k: str(v) for k, v in cipher.items()}).encode()).decode()

def hash_id(email):
    """Crée un hash SHA-256 de l'email."""
    return hashlib.sha256(email.encode()).hexdigest()

def hash_to_int_list(hashed_id, length=10):
    """Convertit un hash en liste d'entiers."""
    return [int(hashed_id[i:i+2], 16) % 10 for i in range(0, min(len(hashed_id), length * 2), 2)]

class PatientRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput(attrs={"class": "form-control"}))
    confirm_password = forms.CharField(widget=forms.PasswordInput(attrs={"class": "form-control"}))
    date_of_birth = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', "class": "form-control"}))

    class Meta:
        model = Usera
        fields = ['username', 'email', 'password', 'confirm_password', 'date_of_birth']

    def clean(self):
        """Validation des mots de passe."""
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password != confirm_password:
            raise forms.ValidationError("Les mots de passe ne correspondent pas.")
        return cleaned_data

    def save(self, commit=True):
        """Enregistrement du patient avec chiffrement IBE."""
        user = super().save(commit=False)
        
        # Générer un ID IBE basé sur le hash de l'email
        hashed_email = hash_id(user.email)
        ibe_id = hash_to_int_list(hashed_email)

        # Générer la clé privée IBE
        user_key = ibe.KeyGen(params, ibe_id, master_key)

        # Chiffrer username et email avec IBE
        cipher_username = ibe.encrypt(params, ibe_id, user.username)
        cipher_email = ibe.encrypt(params, ibe_id, user.email)

        # Convertir pour stockage
        user.username = serialize_ciphertext(cipher_username)
        user.email = serialize_ciphertext(cipher_email)
        user.role = 'patient'  
        user.set_password(self.cleaned_data['password'])  # Hash du mot de passe

        if commit:
            user.save()
            profile = Profile.objects.create(user=user)
            Patient.objects.create(profile=profile, date_of_birth=self.cleaned_data['date_of_birth'])

            # ⚠️ Il faut stocker la clé privée dans un champ sécurisé en base
            # Exemple : Usera.objects.filter(id=user.id).update(private_key=serialize_ciphertext(user_key))

        return user


class DoctorRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
    confirm_password = forms.CharField(widget=forms.PasswordInput())
    license_number = forms.CharField(required=True)

    class Meta:
        model = Usera
        fields = ['username', 'email']

    def clean_license_number(self):
        license_number = self.cleaned_data.get('license_number')
        if not Doctor.objects.filter(license_number=license_number).exists():
            raise forms.ValidationError("Numéro de licence invalide")
        return license_number

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password != confirm_password:
            raise forms.ValidationError("Les mots de passe ne correspondent pas")

class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ['doctor', 'date', 'notes']
        widgets = {
            'date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }

from django import forms
from .models import MedicalRecord

class MedicalRecordForm(forms.ModelForm):
    class Meta:
        model = MedicalRecord
        fields = [
            'file', 'allergies', 'chronic_diseases', 'medications',
            'previous_surgeries', 'blood_type', 'emergency_contact', 'notes'
        ]
        widgets = {
            'allergies': forms.Textarea(attrs={'rows': 3}),
            'chronic_diseases': forms.Textarea(attrs={'rows': 3}),
            'medications': forms.Textarea(attrs={'rows': 3}),
            'previous_surgeries': forms.Textarea(attrs={'rows': 3}),
            'notes': forms.Textarea(attrs={'rows': 4}),
        }


from django import forms
from .models import Profile

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['phone_number', 'address', 'profile_picture']
        
        widgets = {
            'address': forms.Textarea(attrs={'rows': 4, 'cols': 50}),
        }
